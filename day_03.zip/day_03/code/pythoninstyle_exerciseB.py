    #!/usr/bin/env python


#2.1 Try do understand what the code does
#without executing the code

#2.2 Make a list comprehension for this!

x=0
pS=[]
while x<10:
	x+=1
	if x**2%2 ==0:_
	pS.append(x**2)





